package com.capivara.zap

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class LeitorWhatsApp : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return
        if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val extras = sbn.notification.extras
        val titulo = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val texto = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return

        val contato = Armazenamento.contatos(this).firstOrNull { combina(it, titulo) } ?: return
        val msg = Mensagem(contato.nome, texto, sbn.postTime)
        Armazenamento.adicionarMensagem(this, msg)
        Barramento.publicar(msg)
    }

    // O WhatsApp mostra o nome salvo na agenda, ou o número se a pessoa não está salva.
    private fun combina(c: Contato, titulo: String): Boolean {
        if (titulo.trim().equals(c.nome.trim(), ignoreCase = true)) return true
        val dt = titulo.filter { it.isDigit() }
        val dc = c.telefone.filter { it.isDigit() }
        return dt.length >= 8 && dc.length >= 8 && dt.endsWith(dc.takeLast(8))
    }
}
