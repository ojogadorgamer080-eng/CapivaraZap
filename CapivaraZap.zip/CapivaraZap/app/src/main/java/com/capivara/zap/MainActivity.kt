package com.capivara.zap

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var listaContatos: LinearLayout
    private lateinit var caixaMensagens: TextView
    private val ouvinte: (Mensagem) -> Unit = { runOnUiThread { mostrarMensagens() } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val raiz = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        val nome = EditText(this).apply { hint = "Nome (igual ao da agenda do WhatsApp)" }
        val tel = EditText(this).apply { hint = "Telefone"; inputType = InputType.TYPE_CLASS_PHONE }
        val add = Button(this).apply { text = "Adicionar contato" }
        val perm = Button(this).apply { text = "Dar permissão de notificações" }
        listaContatos = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        caixaMensagens = TextView(this).apply { textSize = 15f }

        add.setOnClickListener {
            val n = nome.text.toString().trim(); val t = tel.text.toString().trim()
            if (n.isEmpty() || t.isEmpty()) return@setOnClickListener
            Armazenamento.salvarContatos(this, Armazenamento.contatos(this) + Contato(n, t))
            nome.text.clear(); tel.text.clear(); mostrarContatos()
        }
        perm.setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }

        listOf(nome, tel, add, perm, TextView(this).apply { text = "\nContatos (toque para remover):" },
            listaContatos, TextView(this).apply { text = "\nMensagens recebidas:" }, caixaMensagens)
            .forEach { raiz.addView(it) }
        setContentView(ScrollView(this).apply { addView(raiz) })
        mostrarContatos(); mostrarMensagens()
    }

    override fun onStart() { super.onStart(); Barramento.ouvintes.add(ouvinte); mostrarMensagens() }
    override fun onStop() { super.onStop(); Barramento.ouvintes.remove(ouvinte) }

    private fun mostrarContatos() {
        listaContatos.removeAllViews()
        Armazenamento.contatos(this).forEach { c ->
            listaContatos.addView(TextView(this).apply {
                text = "• ${c.nome}  (${c.telefone})"; textSize = 16f; setPadding(0, 14, 0, 14)
                setOnClickListener {
                    Armazenamento.salvarContatos(this@MainActivity, Armazenamento.contatos(this@MainActivity) - c)
                    mostrarContatos()
                }
            })
        }
    }

    private fun mostrarMensagens() {
        val f = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
        caixaMensagens.text = Armazenamento.mensagens(this).reversed()
            .joinToString("\n\n") { "${it.nome} (${f.format(Date(it.hora))})\n${it.texto}" }
            .ifEmpty { "Nenhuma ainda." }
    }
}
