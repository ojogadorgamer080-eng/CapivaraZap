package com.capivara.zap

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Contato(val nome: String, val telefone: String)
data class Mensagem(val nome: String, val texto: String, val hora: Long)

object Armazenamento {
    private fun prefs(c: Context) = c.getSharedPreferences("capivara", Context.MODE_PRIVATE)

    fun contatos(c: Context): List<Contato> {
        val a = JSONArray(prefs(c).getString("contatos", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it); Contato(o.getString("nome"), o.getString("telefone"))
        }
    }

    fun salvarContatos(c: Context, lista: List<Contato>) {
        val a = JSONArray()
        lista.forEach { a.put(JSONObject().put("nome", it.nome).put("telefone", it.telefone)) }
        prefs(c).edit().putString("contatos", a.toString()).apply()
    }

    fun mensagens(c: Context): List<Mensagem> {
        val a = JSONArray(prefs(c).getString("mensagens", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it); Mensagem(o.getString("nome"), o.getString("texto"), o.getLong("hora"))
        }
    }

    fun adicionarMensagem(c: Context, m: Mensagem) {
        val lista = mensagens(c)
        if (lista.lastOrNull() == m) return // WhatsApp repete notificações
        val nova = (lista + m).takeLast(200)
        val a = JSONArray()
        nova.forEach { a.put(JSONObject().put("nome", it.nome).put("texto", it.texto).put("hora", it.hora)) }
        prefs(c).edit().putString("mensagens", a.toString()).apply()
    }
}

// ENCAIXE: qualquer peça nova (ex.: tela de mensagens, alertas) se inscreve aqui
object Barramento {
    val ouvintes = mutableSetOf<(Mensagem) -> Unit>()
    fun publicar(m: Mensagem) = ouvintes.toList().forEach { it(m) }
}
